@extends('common.master') 

@section('breadcrumbs')

<ol class="breadcrumb breadcrumb-transparent nm">
    <li class="active">Dashboard</li>
</ol>

@stop 

@section('content')

@stop
