<div class="col-sm-6">
    <div class="form-group">
        <label class="col-sm-4 control-label" for="area_4">Area:</label>
        <label class="col-sm-8 control-label control-label-value">{{ $unit->total_land_area }} m<sub>2</sub></label>
    </div>
</div>
<div class="col-sm-6">
    <div class="form-group">
        <label class="col-sm-5 control-label" for="percentage_of_built_area_4">Percentage of Built Area:</label>
        <label class="col-sm-7 control-label control-label-value">{{ $unit->percentage_of_built_area }} %</label>
    </div>
</div>