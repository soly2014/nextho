<ol class="breadcrumb breadcrumb-transparent nm">
<?php
    // if(isset($breadcrumbs)){
    //     $crumbs_count = COUNT($breadcrumbs);
    //     $tail = $breadcrumbs[0];

    //     foreach($tail as $crumb){
    //         --$crumbs_count;
    //         $current = $crumb[0];

    //         $current_text = '<li '.(($crumbs_count < 0) ? 'class="active"' : '').'>'.($current['crumb_link'] != "" ? '<a href="'.route($current['crumb_link']).'">' : '').$current['crumb_name'].($current['crumb_link'] != "" ? '</a>' : '').'</li>';

    //         echo $current_text;   
    //     }
    // }
?>

</ol>