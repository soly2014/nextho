<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ClientDeveloper extends Model
{

    protected $table = 'clients_developers';

    protected $guarded = [];



}
