<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Resale extends Model
{
    protected $guarded = [];
}
